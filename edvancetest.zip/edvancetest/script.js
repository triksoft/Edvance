function login() {
    const user = document.getElementById("username").value;
    const pass = document.getElementById("password").value;
  
    if (user === "student" && pass === "1234") {
      window.location.href = "home.html";
    } else {
      document.getElementById("errorMsg").textContent = "Invalid credentials!";
    }
  }
  
  const subjectData = {
    cse: {
      "Optimization Techniques": {
        prerequisites: "Math basics",
        application: "Machine Learning, AI",
        career: "Optimization engineer",
        faculty: ["Dr. Ramesh Kumar", "Dr. Priya Sharma"]
      },
      "Digital Electronics": {
        prerequisites: "Physics",
        application: "Hardware design",
        career: "VLSI engineer",
        faculty: ["Dr. Rajesh Yadav", "Dr. Aarti Patel"]
      }
    },
    ece: {
      "Signal Processing": {
        prerequisites: "Math, Linear Algebra",
        application: "Speech & Image processing",
        career: "DSP Engineer",
        faculty: ["Dr. Meena Rao", "Dr. Krishna"]
      }
    }
  };
  
  function loadSubjects() {
    const dept = document.getElementById("departmentDropdown").value;
    const subjectDropdown = document.getElementById("subjectDropdown");
    const subjectContainer = document.getElementById("subjectContainer");
  
    subjectDropdown.innerHTML = `<option value="">Select Subject</option>`;
    if (dept && subjectData[dept]) {
      Object.keys(subjectData[dept]).forEach(subject => {
        const option = document.createElement("option");
        option.value = subject;
        option.textContent = subject;
        subjectDropdown.appendChild(option);
      });
      subjectContainer.style.display = "block";
    } else {
      subjectContainer.style.display = "none";
    }
  }
  
  function displaySubjectInfo() {
    const dept = document.getElementById("departmentDropdown").value;
    const subject = document.getElementById("subjectDropdown").value;
    const details = subjectData[dept]?.[subject];
  
    if (details) {
      const infoHTML = `
        <div class="card p-4 shadow-sm">
          <h4>${subject}</h4>
          <p><strong>Prerequisites:</strong> ${details.prerequisites}</p>
          <p><strong>Real-world Applications:</strong> ${details.application}</p>
          <p><strong>Career Insights:</strong> ${details.career}</p>
          <p><strong>Faculty:</strong><br> ${details.faculty.map(f => "- " + f).join("<br>")}</p>
        </div>
      `;
      document.getElementById("courseDetails").innerHTML = infoHTML;
      document.getElementById("courseDetails").style.display = "block";
    }
  }